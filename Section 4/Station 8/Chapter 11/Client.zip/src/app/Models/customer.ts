export class Customer {
  constructor(public FName:string, public LName:string) {
  }
}
